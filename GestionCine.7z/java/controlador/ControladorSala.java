package controlador;

import modelo.Sala;
import modelo.ConexionDB;
import vista.PanelSalas;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ControladorSala {
    private ConexionDB conexion;
    private PanelSalas panelSalas;

    public ControladorSala(PanelSalas panel) {
        this.conexion = new ConexionDB();
        this.panelSalas = panel;
        cargarSalas();
    }

    public void cargarSalas() {
        ArrayList<Sala> listaSalas = new ArrayList<>();
        String sql = "SELECT * FROM sala";
        
        try (Connection conn = conexion.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Sala sala = new Sala(rs.getInt("id"), rs.getString("nombre"), rs.getInt("capacidad"));
                listaSalas.add(sala);
            }
            panelSalas.mostrarSalas(listaSalas);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(panelSalas, "Error al cargar salas: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void agregarSala(String nombre, int capacidad) {
        String sql = "INSERT INTO sala (nombre, capacidad) VALUES (?, ?)";
        
        try (Connection conn = conexion.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setInt(2, capacidad);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(panelSalas, "Sala agregada correctamente.");
            cargarSalas();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(panelSalas, "Error al agregar sala: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
