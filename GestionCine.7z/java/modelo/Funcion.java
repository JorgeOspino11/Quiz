package modelo;

public class Funcion {
    private int idFuncion;
    private int idSala;
    private int idPelicula;
    private String horario; // Ejemplo: "14:00", "18:30"

    public Funcion() {}

    public Funcion(int idFuncion, int idSala, int idPelicula, String horario) {
        this.idFuncion = idFuncion;
        this.idSala = idSala;
        this.idPelicula = idPelicula;
        this.horario = horario;
    }

    public int getIdFuncion() {
        return idFuncion;
    }

    public void setIdFuncion(int idFuncion) {
        this.idFuncion = idFuncion;
    }

    public int getIdSala() {
        return idSala;
    }

    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }

    public int getIdPelicula() {
        return idPelicula;
    }

    public void setIdPelicula(int idPelicula) {
        this.idPelicula = idPelicula;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    @Override
    public String toString() {
        return "Funcion{" + "idFuncion=" + idFuncion + ", idSala=" + idSala + 
               ", idPelicula=" + idPelicula + ", horario=" + horario + '}';
    }
}
