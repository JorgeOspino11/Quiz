package dao;
import modelo.Cine;
import java.sql.*;
import java.util.ArrayList;

public class CineDAO {
    private Connection con;

    public CineDAO(Connection con) {
        this.con = con;
    }

    public ArrayList<Cine> obtenerCines() {
        ArrayList<Cine> lista = new ArrayList<>();
        String sql = "SELECT * FROM cine";
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                lista.add(new Cine(rs.getInt("id_cine"), rs.getString("nombre"), rs.getString("direccion")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}

