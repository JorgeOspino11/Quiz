package controlador;

import modelo.Cine;
import modelo.ConexionDB;
import vista.PanelCines;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ControladorCine {
    private ConexionDB conexion;
    private PanelCines panelCines;

    public ControladorCine(PanelCines panel) {
        this.conexion = new ConexionDB();
        this.panelCines = panel;
        cargarCines();
    }

    public void cargarCines() {
        ArrayList<Cine> listaCines = new ArrayList<>();
        String sql = "SELECT * FROM cine";
        
        try (Connection conn = conexion.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Cine cine = new Cine(rs.getInt("id"), rs.getString("nombre"), rs.getString("direccion"));
                listaCines.add(cine);
            }
            panelCines.mostrarCines(listaCines);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(panelCines, "Error al cargar cines: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void agregarCine(String nombre, String direccion) {
        String sql = "INSERT INTO cine (nombre, direccion) VALUES (?, ?)";
        
        try (Connection conn = conexion.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setString(2, direccion);
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(panelCines, "Cine agregado correctamente.");
            cargarCines();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(panelCines, "Error al agregar cine: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
