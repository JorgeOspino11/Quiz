package modelo;
public class Cine {
    
    private int idCine;
    private String nombre;
    private String direccion;

    public Cine(int idCine, String nombre, String direccion) {
        this.idCine = idCine;
        this.nombre = nombre;
        this.direccion = direccion;
    }

    // Getters y Setters
}
  
