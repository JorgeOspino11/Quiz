package vista;

import controlador.ControladorSala;
import modelo.Sala;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelSalas extends JInternalFrame {
    private JTextField txtNombre, txtCapacidad;
    private JButton btnAgregar, btnActualizar, btnEliminar;
    private JTable tablaSalas;
    private DefaultTableModel modeloTabla;
    private ControladorSala ControladorSala;

    public PanelSalas() {
        super("Gestión de Salas", true, true, true, true);
        setSize(500, 400);
        setLayout(new BorderLayout());

        ControladorSala = new ControladorSala();

        JPanel panelSuperior = new JPanel(new GridLayout(2, 2, 5, 5));
        panelSuperior.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelSuperior.add(txtNombre);
        panelSuperior.add(new JLabel("Capacidad:"));
        txtCapacidad = new JTextField();
        panelSuperior.add(txtCapacidad);
        add(panelSuperior, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new String[]{"ID", "Nombre", "Capacidad"}, 0);
        tablaSalas = new JTable(modeloTabla);
        add(new JScrollPane(tablaSalas), BorderLayout.CENTER);

        JPanel panelInferior = new JPanel();
        btnAgregar = new JButton("Agregar");
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");
        panelInferior.add(btnAgregar);
        panelInferior.add(btnActualizar);
        panelInferior.add(btnEliminar);
        add(panelInferior, BorderLayout.SOUTH);

        cargarSalas();

        btnAgregar.addActionListener(e -> agregarSala());
        btnActualizar.addActionListener(e -> actualizarSala());
        btnEliminar.addActionListener(e -> eliminarSala());
    }

    private void cargarSalas() {
        modeloTabla.setRowCount(0);
        List<Sala> salas = ControladorSala.obtenerSalas();
        for (Sala sala : salas) {
            modeloTabla.addRow(new Object[]{sala.getId(), sala.getNombre(), sala.getCapacidad()});
        }
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

