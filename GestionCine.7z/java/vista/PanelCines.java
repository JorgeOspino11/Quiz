package vista;

import controlador.ControladorCine;
import modelo.Cine;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelCines extends JInternalFrame {
    private JTextField txtNombre, txtDireccion;
    private JButton btnAgregar, btnActualizar, btnEliminar;
    private JTable tablaCines;
    private DefaultTableModel modeloTabla;
    private ControladorCine controladorCine;

    public PanelCines() {
        super("Gestión de Cines", true, true, true, true);
        setSize(500, 400);
        setLayout(new BorderLayout());

        controladorCine = new ControladorCine();

        // Panel superior con los campos
        JPanel panelSuperior = new JPanel(new GridLayout(2, 2, 5, 5));
        panelSuperior.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelSuperior.add(txtNombre);
        panelSuperior.add(new JLabel("Dirección:"));
        txtDireccion = new JTextField();
        panelSuperior.add(txtDireccion);
        add(panelSuperior, BorderLayout.NORTH);

        // Tabla con los cines
        modeloTabla = new DefaultTableModel(new String[]{"ID", "Nombre", "Dirección"}, 0);
        tablaCines = new JTable(modeloTabla);
        add(new JScrollPane(tablaCines), BorderLayout.CENTER);

        // Panel inferior con botones
        JPanel panelInferior = new JPanel();
        btnAgregar = new JButton("Agregar");
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");
        panelInferior.add(btnAgregar);
        panelInferior.add(btnActualizar);
        panelInferior.add(btnEliminar);
        add(panelInferior, BorderLayout.SOUTH);

        // Cargar datos
        cargarCines();

        btnAgregar.addActionListener(e -> agregarCine());
        btnActualizar.addActionListener(e -> actualizarCine());
        btnEliminar.addActionListener(e -> eliminarCine());
    }

    private void cargarCines() {
        modeloTabla.setRowCount(0);
        List<Cine> cines = controladorCine.obtenerCines();
        for (Cine cine : cines) {
            modeloTabla.addRow(new Object[]{cine.getId(), cine.getNombre(), cine.getDireccion()});
        }
    }

    private void agregarCine() {
        String nombre = txtNombre.getText();
        String direccion = txtDireccion.getText();
        if (!nombre.isEmpty() && !direccion.isEmpty()) {
            controladorCine.agregarCine(new Cine(0, nombre, direccion));
            cargarCines();
        }
    }

    private void actualizarCine() {
        int fila = tablaCines.getSelectedRow();
        if (fila >= 0) {
            int id = (int) modeloTabla.getValueAt(fila, 0);
            String nombre = txtNombre.getText();
            String direccion = txtDireccion.getText();
            controladorCine.actualizarCine(new Cine(id, nombre, direccion));
            cargarCines();
        }
    }

    private void eliminarCine() {
        int fila = tablaCines.getSelectedRow();
        if (fila >= 0) {
            int id = (int) modeloTabla.getValueAt(fila, 0);
            controladorCine.eliminarCine(id);
            cargarCines();
        }
    }
}

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

