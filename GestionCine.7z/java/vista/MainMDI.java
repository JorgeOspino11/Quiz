package vista;

import javax.swing.*;
import java.awt.*;
import controlador.ControladorCine;
import controlador.ControladorSala;

public class MainMDI extends JFrame {
    private JDesktopPane desktopPane;
    private JMenuBar menuBar;
    private JMenu menuGestion;
    private JMenuItem itemCines, itemSalas;
    
    public MainMDI() {
        setTitle("Sistema de Gestión de Cine");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        desktopPane = new JDesktopPane();
        setContentPane(desktopPane);
        
        menuBar = new JMenuBar();
        menuGestion = new JMenu("Gestión");
        itemCines = new JMenuItem("Gestionar Cines");
        itemSalas = new JMenuItem("Gestionar Salas");
        
        itemCines.addActionListener(e -> abrirPanelCines());
        itemSalas.addActionListener(e -> abrirPanelSalas());
        
        menuGestion.add(itemCines);
        menuGestion.add(itemSalas);
        menuBar.add(menuGestion);
        setJMenuBar(menuBar);
    }
    
    private void abrirPanelCines() {
        PanelCines panelCines = new PanelCines(new ControladorCine());
        desktopPane.add(panelCines);
        panelCines.setVisible(true);
    }
    
    private void abrirPanelSalas() {
        PanelSalas panelSalas = new PanelSalas(new ControladorSala());
        desktopPane.add(panelSalas);
        panelSalas.setVisible(true);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MainMDI().setVisible(true);
        });
    }
}

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

