package modelo;

public class Pelicula {
    private int idPelicula;
    private String titulo;
    private String genero;
    private int duracion; // Duración en minutos
    private String clasificacion; // Ej: "PG-13", "R"
    private String director;

    // Constructor vacío
    public Pelicula() {}

    // Constructor con parámetros
    public Pelicula(int idPelicula, String titulo, String genero, int duracion, String clasificacion, String director) {
        this.idPelicula = idPelicula;
        this.titulo = titulo;
        this.genero = genero;
        this.duracion = duracion;
        this.clasificacion = clasificacion;
        this.director = director;
    }

    // Getters y Setters
    public int getIdPelicula() {
        return idPelicula;
    }

    public void setIdPelicula(int idPelicula) {
        this.idPelicula = idPelicula;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public String getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(String clasificacion) {
        this.clasificacion = clasificacion;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    // Método toString para mostrar la información de la película
    @Override
    public String toString() {
        return "Pelicula{" + "id=" + idPelicula + ", titulo=" + titulo + ", genero=" + genero + 
               ", duracion=" + duracion + " min, clasificacion=" + clasificacion + ", director=" + director + '}';
    }
}




